To run :
Open the .ipynb file with jupyter notebook.
To re-train:
Press the Run all options under the option cell.
